document.getElementById('predictionForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('/', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('resultSection').classList.remove('hidden');
        document.getElementById('riskLevel').textContent = data.risk_level;
        document.getElementById('rainfallValue').textContent = `${data.water_quality.rainfall_mm} mm`;
        document.getElementById('phValue').textContent = data.water_quality.pH;
        document.getElementById('tdsValue').textContent = 'N/A'; // Placeholder
        document.getElementById('turbidityValue').textContent = `${data.water_quality.turbidity_NTU} NTU`;
        document.getElementById('doValue').textContent = `${data.water_quality.dissolved_oxygen_mg_L} mg/L`;
        document.getElementById('coliformValue').textContent = `${data.water_quality.total_coliform_MPN} MPN/100mL`;
        document.getElementById('nitrateValue').textContent = '7.22 mg/L'; // Placeholder
        document.getElementById('diseaseDetected').textContent = data.primary_diseases.join(', ');
        document.getElementById('geoLocation').textContent = `${data.state} - ${data.month} ${data.year}`;
        document.getElementById('searchLocation').textContent = `${data.state}, ${data.month} ${data.year}`;

        // Status logic
        document.getElementById('rainfallStatus').textContent = 'Safe';
        document.getElementById('phStatus').textContent = data.water_quality.pH < 6.5 || data.water_quality.pH > 8.5 ? 'Unsafe' : 'Safe';
        document.getElementById('tdsStatus').textContent = 'Safe'; // Placeholder
        document.getElementById('turbidityStatus').textContent = data.water_quality.turbidity_NTU > 5 ? 'Unsafe' : 'Safe';
        document.getElementById('doStatus').textContent = data.water_quality.dissolved_oxygen_mg_L < 5 ? 'Unsafe' : 'Safe';
        document.getElementById('coliformStatus').textContent = data.water_quality.total_coliform_MPN > 100 ? 'Caution' : 'Safe';
        document.getElementById('nitrateStatus').textContent = 'Safe'; // Placeholder

        // Disease Chart
        const ctxDisease = document.getElementById('diseaseChart').getContext('2d');
        if (window.diseaseChart) window.diseaseChart.destroy();
        window.diseaseChart = new Chart(ctxDisease, {
            type: 'bar',
            data: {
                labels: data.primary_diseases,
                datasets: [{
                    label: 'Disease Risk',
                    data: [1, 1], // Placeholder data
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: { y: { beginAtZero: true } }
            }
        });

        // Trend Chart
        const ctxTrend = document.getElementById('trendChart').getContext('2d');
        if (window.trendChart) window.trendChart.destroy();
        window.trendChart = new Chart(ctxTrend, {
            type: 'line',
            data: {
                labels: ['2018', '2019', '2020', '2021', '2022', '2023', '2024'],
                datasets: [{
                    label: 'Risk Score',
                    data: [0.5, 0.7, 1.2, 0.9, 1.5, 1.3, 1.0], // Placeholder data
                    borderColor: 'rgba(255, 99, 132, 1)',
                    fill: false
                }]
            },
            options: {
                scales: { y: { beginAtZero: true } }
            }
        });
    })
    .catch(error => console.error('Error:', error));
});